# KYMAK
Baseado no OpenTune (by Arturo254), licença GPL-3.0. Código-fonte aberto conforme a licença.
